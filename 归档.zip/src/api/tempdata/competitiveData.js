const CompetitiveData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 3,
		"data": [
			{
				"id": 0,
				"name": "全部"  
			},{
				"id": 1,
				"name": "奥迪"  
			},{
				"id": 2,
				"name": "宝马"  
			},{
				"id": 3,
				"name": "雨晨"  
			}
		]
	}
}

module.exports = CompetitiveData; 