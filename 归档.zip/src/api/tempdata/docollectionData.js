/*
* @Created Date:   2018-05-22 16:16:03
* @Author: yiche
* ------
* @Last Modified: 2018-05-25 16:42:31
* @Modified by:   yiche
* ------
* Copyright (c) 2018 易车
* ---------------------------------------
* Javascript will save your soul!
*/
const DoCollectionData = {
	"ret_code": 0,
	"msg": "success"
}

module.exports = DoCollectionData; 