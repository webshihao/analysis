const ReportListData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 10,
		"data": [
			{
				"id": 0,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告111111"
			},{
				"id": 1,
				"time": "2018.05.02 15:00:00",
				"isTimeout": true,
				"name": "报告222222"
			},{
				"id": 2,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告333333"
			},{
				"id": 3,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告444444"
			},{
				"id": 4,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告555555"
			},{
				"id": 5,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告666666"
			},{
				"id": 6,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告777777"
			},{
				"id": 7,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告888888"
			},{
				"id": 8,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告999999"
			},{
				"id": 9,
				"time": "2018.05.02 15:00:00",
				"isTimeout": false,
				"name": "报告101010101010"
			}

		]
	}
}

module.exports = ReportListData; 