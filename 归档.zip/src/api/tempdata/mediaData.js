/*
* @Created Date:   2018-05-22 16:23:01
* @Author: yiche
* ------
* @Last Modified: 2018-05-22 16:24:07
* @Modified by:   yiche
* ------
* Copyright (c) 2018 易车
* ---------------------------------------
* Javascript will save your soul!
*/
const MediaData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 3,
		"data": [
			{
				"id": 0,
				"name": "全部"  
			},{
				"id": 1,
				"name": "新闻"  
			},{
				"id": 2,
				"name": "微博"  
			},{
				"id": 3,
				"name": "微信"  
			}
		]
	}
}

module.exports = MediaData; 