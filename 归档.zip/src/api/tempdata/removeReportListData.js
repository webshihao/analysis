const RemoveReportListData = {
	"ret_code": 0,
	"msg": "success",
	result:{}
}
module.exports = RemoveReportListData; 