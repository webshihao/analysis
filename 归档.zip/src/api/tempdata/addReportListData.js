const AddReportListData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 4,
		"data": [
			{
				"id": 0,
				"isChecked": false,
				"name": "报告1"  
			},{
				"id": 1,
				"isChecked": true,
				"name": "报告2"  
			},{
				"id": 2,
				"isChecked": false,
				"name": "报告3"  
			},{
				"id": 3,
				"isChecked": false,
				"name": "报告4"  
			},{
				"id": 4,
				"isChecked": false,
				"name": "报告5"  
			}
		]
	}
}

module.exports = AddReportListData; 