const ChangeReportListData = {
	"ret_code": 0,
	"msg": "success"
}

module.exports = ChangeReportListData; 