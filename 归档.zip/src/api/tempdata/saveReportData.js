/*
* @Created Date:   2018-05-22 16:16:03
* @Author: yiche
* ------
* @Last Modified: 2018-05-31 10:58:20
* @Modified by:   yiche
* ------
* Copyright (c) 2018 易车
* ---------------------------------------
* Javascript will save your soul!
*/
const SaveReportData = {
	"ret_code": 0,
	"msg": "success"
}

module.exports = SaveReportData; 