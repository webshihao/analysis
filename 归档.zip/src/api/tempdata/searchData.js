/*
* @Created Date:   2018-05-22 16:23:01
* @Author: yiche
* ------
* @Last Modified: 2018-05-23 15:52:54
* @Modified by:   yiche
* ------
* Copyright (c) 2018 易车
* ---------------------------------------
* Javascript will save your soul!
*/
const SearchData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 5,
		"data": [
			{
				"id": 0,
				"name": "北京车展"  
			},{
				"id": 1,
				"name": "超人"  
			},{
				"id": 2,
				"name": "动感超人"  
			},{
				"id": 3,
				"name": "关羽"  
			},{
				"id": 4,
				"name": "关二爷"  
			}
		]
	}
}

module.exports = SearchData; 