const LoginData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"isDefault": true
	}
}

module.exports = LoginData; 