const GetReportListData = {
	"ret_code": 0,
	"msg": "success",
	"result": {
		"data_num": 3,
		"data": [
			{
				"id": 0,
				"isChecked": false,
				"name": "报告1"  
			},{
				"id": 1,
				"isChecked": true,
				"name": "报告2"  
			},{
				"id": 2,
				"isChecked": false,
				"name": "报告3"  
			},{
				"id": 3,
				"isChecked": false,
				"name": "报告4"  
			}
		]
	}
}

module.exports = GetReportListData; 