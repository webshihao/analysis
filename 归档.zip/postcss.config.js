/*
* @Created Date:   2018-06-04 10:05:31
* @Author: huke
* ------
* @Last Modified: 2018-06-04 10:05:38
* @Modified by:   huke
* ------
* Copyright (c) 2018 易车
* ---------------------------------------
* Javascript will save your soul!
*/
module.exports = { 
  plugins: { 
    'autoprefixer': {browsers: 'last 5 version'} 
  } 
}